public class Main {
    public static void main(String[] args) {
        //no funciona al agregar mas numeros
        int [] array = {4,8,9};
        MaxHeap maxHeap = new MaxHeap(array);
        System.out.println();
        maxHeap.printHeap();
    }
}