import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class Arbol {
    Nodo raiz;

    public List<Integer> recorridoEnAnchura() {
        List<Integer> resultado = new ArrayList<>();

        if (raiz == null) {
            return resultado;
        }

        Queue<Nodo> cola = new LinkedList<>();
        cola.offer(raiz);

        while (!cola.isEmpty()) {
            Nodo nodoActual = cola.poll();
            resultado.add(nodoActual.num);

            if (nodoActual.izq != null) {
                cola.offer(nodoActual.izq);
            }

            if (nodoActual.der != null) {
                cola.offer(nodoActual.der);
            }
        }

        return resultado;
    }
}
