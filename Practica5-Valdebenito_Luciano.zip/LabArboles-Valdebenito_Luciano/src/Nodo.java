public class Nodo {
    int num;
    Nodo izq;
    Nodo der;

    public Nodo(int num) {
        this.num = num;
        this.izq = null;
        this.der = null;
    }
}
