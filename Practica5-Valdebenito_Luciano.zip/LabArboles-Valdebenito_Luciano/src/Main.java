import java.util.List;

public class Main {
    public static void main(String[] args) {

        Arbol arbol = new Arbol();
        arbol.raiz = new Nodo(1);
        arbol.raiz.izq = new Nodo(2);
        arbol.raiz.der = new Nodo(3);
        arbol.raiz.izq.izq = new Nodo(4);
        arbol.raiz.izq.der = new Nodo(5);
        arbol.raiz.izq.der.izq = new Nodo(6);
        arbol.raiz.izq.der.izq.izq = new Nodo(7);
        arbol.raiz.izq.der.der = new Nodo(8);
        //arbol.raiz.izq.der.izq = new Nodo(6);


        List<Integer> resultado = arbol.recorridoEnAnchura();
        System.out.println("Recorrido en anchura: " + resultado);
    }

    public static void insertarNum(){

    }
}

