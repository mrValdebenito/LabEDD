import java.util.Random;

public class Main {
    public static void main(String[] args) {

            ListaEnlazada lista = new ListaEnlazada();
        Random random = new Random();
        for (int i = 0; i < 10; i++) {
            int num = random.nextInt(100);
            lista.agregarElemento(num);
        }
        System.out.println("Lista desordenada:");
        lista.imprimirLista();
        lista.ordenaLista();
        System.out.println("Lista ordenada:");
        lista.imprimirLista();

    }
}