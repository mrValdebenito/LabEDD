import java.util.Random;

public class Nodo {

    int dato;
    Nodo siguiente;

    public Nodo(int dato) {
        Random random = new Random();
        this.dato = random.nextInt(20);
        this.siguiente = null;
    }
}
