import java.util.Random;

public class Main {
    public static void main(String[] args) {

        ListaEnlazada lista1 = new ListaEnlazada();
        ListaEnlazada2 lista2 = new ListaEnlazada2();
        ListaEnlazada lista3 = new ListaEnlazada();
        Random random = new Random();
        for (int i = 0; i < 10; i++) {
            int num = random.nextInt(100);
            lista1.agregarElemento(num);
        }

        for (int i = 0; i < 10; i++) {
            int num = random.nextInt(100);
            lista2.agregarElemento(num);
        }

        System.out.println("Lista 1 desordenada:");
        lista1.imprimirLista();
        lista1.ordenaLista();

        System.out.println("Lista 2 desordenada:");
        lista2.imprimirLista();
        lista2.ordenaLista();

        System.out.println("Lista 1 ordenada:");
        lista1.imprimirLista();

        System.out.println("Lista 2 ordenada:");
        lista2.imprimirLista();

        int promedioLista1 = 0;

        System.out.println();

        for (int i = 0; i < 1; i++) {
            Nodo temp = lista1.cabeza;
            while (temp != null) {
                System.out.print(temp.dato + "-");
                promedioLista1 = promedioLista1 + temp.dato;
                temp = temp.siguiente;
            }
            System.out.println();
        }
        System.out.println(promedioLista1);
        promedioLista1 = promedioLista1/10;
        System.out.println(promedioLista1);

        System.out.println();

        int promedioLista2 = 0;
        for (int i = 0; i < 1; i++) {
            Nodo temp = lista2.cabeza;
            while (temp != null) {
                System.out.print(temp.dato + "-");
                promedioLista2 = promedioLista2 + temp.dato;
                temp = temp.siguiente;
            }
            System.out.println();
        }
        System.out.println(promedioLista2);
        promedioLista2 = promedioLista2/10;
        System.out.println(promedioLista2);

        System.out.println();

        //HACER CONDICION IF, PONER NUMEROS MAYOR PROMEDIO
        for (int i = 0; i < 1; i++) {
            Nodo temp = lista1.cabeza;
            while (temp != null) {
                if (temp.dato>promedioLista1){
                    System.out.print(temp.dato + "-");
                    lista3.agregarElemento(temp.dato);
                }
                temp = temp.siguiente;
            }
            System.out.println();
        }

        System.out.println();

        for (int i = 0; i < 1; i++) {
            Nodo temp = lista2.cabeza;
            while (temp != null) {
                if (temp.dato>promedioLista2){
                    System.out.print(temp.dato + "-");
                    lista3.agregarElemento(temp.dato);
                }
                temp = temp.siguiente;
            }
            System.out.println();
        }

        System.out.println();
        lista3.imprimirLista();

    }
}