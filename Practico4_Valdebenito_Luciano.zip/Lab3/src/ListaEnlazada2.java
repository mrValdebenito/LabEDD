public class ListaEnlazada2 {

    Nodo cabeza;

    public ListaEnlazada2() {
        this.cabeza = null;
    }

    public void agregarElemento(int dato) {
        Nodo nuevoNodo = new Nodo(dato);
        if (cabeza == null) {
            cabeza = nuevoNodo;
        } else {
            Nodo temp = cabeza;
            while (temp.siguiente != null) {
                temp = temp.siguiente;
            }
            temp.siguiente = nuevoNodo;
        }
    }

    public void imprimirLista() {
        Nodo temp = cabeza;
        while (temp != null) {
            System.out.print(temp.dato + "-");
            temp = temp.siguiente;
        }
        System.out.println();
    }

    public void ordenaLista() {
        if (cabeza == null || cabeza.siguiente == null) {
            return;
        }

        Nodo a = cabeza;
        while (a != null) {
            Nodo menor = a;
            Nodo siguiente = a.siguiente;

            while (siguiente != null) {
                if (siguiente.dato < menor.dato) {
                    menor = siguiente;
                }
                siguiente = siguiente.siguiente;
            }

            // Intercambiar los datos
            int temp = a.dato;
            a.dato = menor.dato;
            menor.dato = temp;

            a = a.siguiente;
        }
    }
}
