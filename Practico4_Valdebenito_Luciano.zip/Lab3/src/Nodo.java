import java.util.Random;

public class Nodo {

    int dato;
    Nodo siguiente;

    public Nodo(int dato) {
        Random rdm = new Random();
        this.dato = rdm.nextInt(20);
        this.siguiente = null;
    }
}
