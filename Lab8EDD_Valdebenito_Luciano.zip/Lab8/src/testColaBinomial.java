public class testColaBinomial {
    public static void main(String[] args){
        int a[] = {12, 17, 2, 4, 5, 6, 22, 21, 29, 32, 40, 45, 3, 54, 65};
        ColaBinomial b = new ColaBinomial();
        for (int i = 0; i < a.length; i++) b.Insert(a[i]);

        System.out.println();
        b.imprimir();
        System.out.print("Nodos arreglo 1: " + b.size());
        System.out.println();

        a = new int[]{12, 17};
        b = new ColaBinomial();
        for (int i=0; i < a.length;  i++) b.Insert(a[i]);

        System.out.println();
        b.imprimir();
        System.out.print("Nodos arreglo 2: " + b.size());
        System.out.println();

        a = new int[]{1, 2, 3, 4};
        b = new ColaBinomial();
        for (int i=0; i < a.length;  i++) b.Insert(a[i]);

        System.out.println();
        b.imprimir();
        System.out.print("Nodos arreglo 3: " + b.size());
        System.out.println();

    }
}

