package Model;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Animal {

    private String nombreDueno;
    private String nombre;
    private String color;
    private int edad;
    private Date fechaNacimientoo;
    SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");

    public Animal(String nombreDueno, String nombre, String color, int edad, Date fechaNacimiento) {
        this.nombreDueno = nombreDueno;
        this.nombre = nombre;
        this.color = color;
        this.edad = edad;
        this.fechaNacimientoo = fechaNacimiento;
    }


    public String getNombreDueno() {
        return nombreDueno;
    }

    public void setNombreDueno(String nombreDueno) {
        this.nombreDueno = nombreDueno;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public Date getFechaNacimiento() {
        return fechaNacimientoo;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimientoo = fechaNacimiento;
    }

    @Override
    public String toString() {
        return "Animal{" +
                "nombreDueno='" + nombreDueno + '\'' +
                ", nombre='" + nombre + '\'' +
                ", color='" + color + '\'' +
                ", edad=" + edad +
                ", fechaNacimiento=" + fechaNacimientoo +
                '}';
    }
}
