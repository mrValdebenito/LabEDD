package View;

import Controller.Controller;

import javax.swing.plaf.synth.SynthOptionPaneUI;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int opcion;

        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaNacimiento = new Date();
        do {


            System.out.println("MENU");
            System.out.println("1: Agregar mascota");
            System.out.println("2: Eliminar mascota");
            System.out.println("3: Listar mascota");
            System.out.println("4: Salir");
            opcion = in.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("Ingrese nombre dueno");
                    String nombreDueno = in.next();
                    System.out.println("Ingrese nombre mascota");
                    String nombre = in.next();
                    System.out.println("Ingrese color");
                    String color = in.next();
                    System.out.println("Ingrese edad");
                    int edad = in.nextInt();
                    in.nextLine();

                    //OJO FECHA
                    System.out.println("Ingrese fecha nacimiento");
                    String fecha = in.nextLine();
                    SimpleDateFormat spf = new SimpleDateFormat("dd/MM/yyyy");
                    try {
                        Date fechaNacimientoo = spf.parse(fecha);
                        System.out.println("Ingrese tipo de especie 1perro 2gato 3conejo");
                        int especie = in.nextInt();
                        
                            Controller.getInstance().agregarMascota(nombreDueno, nombre, color, edad, fechaNacimientoo, especie);

                    } catch (ParseException e) {
                        throw new RuntimeException(e);
                    }

                    //-------------------


                    /*System.out.println("Ingrese tipo de especie 1perro 2gato 3conejo");
                    int especie = in.nextInt();
                    Controller.getInstance().agregarMascota(nombreDueno, nombre, color, edad, fechaNacimientoo, especie);*/
                    break;
                case 2:
                    Controller.getInstance().listarMascota();
                    System.out.println("Ingrese numero a eliminar");
                    int num = in.nextInt();
                    Controller.getInstance().eliminarMascota(num);
                    break;
                case 3:
                    Controller.getInstance().listarMascota();
                    break;
                case 4:
                    break;
            }
        } while (opcion != 4);
    }
}