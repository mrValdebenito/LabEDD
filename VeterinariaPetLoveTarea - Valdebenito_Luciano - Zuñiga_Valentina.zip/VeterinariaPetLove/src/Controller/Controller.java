package Controller;

import Model.Animal;
import Model.Conejo;
import Model.Gato;
import Model.Perro;

import java.util.ArrayList;
import java.util.Date;

public class Controller {

    public Controller() {
        this.animales = animales;

    }

    private static Controller instance;
    public static Controller getInstance(){
        if (instance == null){
            instance = new Controller();
        }
        return instance;
    }

    ArrayList <Animal> animales = new ArrayList<>();

    int cont = 1;
    public void listarMascota(){
        for (Animal animal : animales){
            System.out.println(cont + ": " + animal.toString());
            cont++;
        }
    }
    public void agregarMascota(String nombreDueno, String nombre, String color, int edad, Date fechaNacimientoo, int numEspecie){
        switch (numEspecie){
            case 1:
                Perro perro = new Perro(nombreDueno, nombre, color, edad, fechaNacimientoo);
                animales.add(perro);
                break;
            case 2:
                Animal gato = new Gato(nombreDueno, nombre, color, edad, fechaNacimientoo);
                animales.add(gato);
                break;
            case 3:
                Animal conejo = new Conejo(nombreDueno, nombre, color, edad, fechaNacimientoo);
                animales.add(conejo);
                break;
        }
    }
    public void eliminarMascota(int num){
        animales.remove(num);
    }



}
