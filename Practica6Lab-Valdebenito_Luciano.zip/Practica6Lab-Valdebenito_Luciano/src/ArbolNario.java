public class ArbolNario {
    public static int totalHojas(Nodo raiz) {
        if (raiz == null) {
            return 0;
        }

        if (raiz.hijo.isEmpty()) {
            return 1;
        }

        int hojas = 0;
        for (Nodo hijo : raiz.hijo) {
            hojas += totalHojas(hijo);
        }

        return hojas;
    }
}
