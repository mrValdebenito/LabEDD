import java.util.List;
import java.util.ArrayList;
public class Nodo {
    int value;
    List<Nodo> hijo;

    public Nodo(int value) {
        this.value = value;
        this.hijo = new ArrayList<>();
    }

    public void agregarHijo(Nodo hijo){
        hijo.agregarHijo(hijo);
    }
}
