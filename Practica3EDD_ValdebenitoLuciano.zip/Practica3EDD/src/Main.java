import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;

public class Main {

    public static ArrayList<Nodo> creaNodos(){
        ArrayList<Nodo> nodos = new ArrayList<Nodo>();
        int numAleatorio;
        for (int i = 0; i < 10; i++) {
            numAleatorio = (int)(Math.random()*10);
            nodos.add(new Nodo(i, numAleatorio));
        }
        return nodos;
    }

    public static void listToArray(ArrayList<Nodo> nodos){
        for(Nodo nodo : nodos){
            for (int i = 0; i < 10; i++) {
                int Array[] array = new int Array[10];
                array[0] = nod;
            }
        }
    }

    public static void main(String[] args) {


        for (int i = 0; i < 10; i++) {
        System.out.println("dato: " + creaNodos().get(i).getDato() + "\tid: " + creaNodos().get(i).getId());
        }

        System.out.println("----------------------------------------------");

        int menor=0;
        int flag=0;
        for (Nodo nodo : creaNodos()){
            creaNodos().sort();
            if (flag==0){
                menor=nodo.getDato();
            }
            flag++;
            if (nodo.getDato() < menor) {
                menor = nodo.getDato();
            }else {
                if (nodo.getDato() > menor){
                    menor = menor;
                }
            }
        System.out.println("dato: " + nodo.getDato() + "\tid: " + nodo.getId());
        }



    }
}