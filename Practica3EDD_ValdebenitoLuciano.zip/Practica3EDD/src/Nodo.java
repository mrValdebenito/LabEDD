import java.util.ArrayList;

public class Nodo {
    private int id;
    private int dato;

    ArrayList<Nodo> nodos = new ArrayList<>();

    public Nodo(int id, int dato) {
        this.id = id;
        this.dato = dato;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDato() {
        return dato;
    }

    public void setDato(int dato) {
        this.dato = dato;
    }


}
